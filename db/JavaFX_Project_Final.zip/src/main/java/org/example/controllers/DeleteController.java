
package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DeleteController {

    @FXML
    private ComboBox<Integer> idComboBox;

    public void initialize() {
        // Populate the ID ComboBox with existing record IDs
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:c:/adatok/adatok.sqlite");
             PreparedStatement pstmt = conn.prepareStatement("SELECT id FROM nezo");
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                idComboBox.getItems().add(rs.getInt("id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteRecord() {
        Integer id = idComboBox.getValue();

        if (id == null) {
            System.out.println("Nincs kiválasztva törlendő rekord!");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:c:/adatok/adatok.sqlite");
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM nezo WHERE id = ?")) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            System.out.println("Rekord sikeresen törölve!");
            idComboBox.getItems().remove(id); // Update the ComboBox after deletion
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
