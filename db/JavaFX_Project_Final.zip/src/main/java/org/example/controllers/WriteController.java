
package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class WriteController {

    @FXML
    private TextField nameField;

    @FXML
    private ComboBox<String> genderComboBox;

    @FXML
    private CheckBox subscriptionCheckBox;

    @FXML
    private void addRecord() {
        String name = nameField.getText();
        String gender = genderComboBox.getValue();
        boolean isSubscriber = subscriptionCheckBox.isSelected();

        if (name == null || name.isEmpty() || gender == null) {
            System.out.println("Hibás adatok! A név és nem mező kötelező.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:c:/adatok/adatok.sqlite");
             PreparedStatement pstmt = conn.prepareStatement(
                 "INSERT INTO nezo (nev, ferfi, berletes) VALUES (?, ?, ?)")) {
            pstmt.setString(1, name);
            pstmt.setString(2, gender.equals("Férfi") ? "true" : "false");
            pstmt.setString(3, isSubscriber ? "true" : "false");
            pstmt.executeUpdate();
            System.out.println("Rekord sikeresen hozzáadva!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
