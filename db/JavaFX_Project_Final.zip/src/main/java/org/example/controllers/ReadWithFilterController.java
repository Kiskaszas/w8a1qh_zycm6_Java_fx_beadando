
package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.models.MeccsModel;

import java.sql.ResultSet;

public class ReadWithFilterController {

    @FXML
    private TextField dateField;

    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    private CheckBox includePremiumCheckBox;

    @FXML
    private TableView<MeccsModel> filteredDataTable;

    @FXML
    private TableColumn<MeccsModel, Integer> idColumn;

    @FXML
    private TableColumn<MeccsModel, String> dateColumn;

    @FXML
    private TableColumn<MeccsModel, String> startTimeColumn;

    @FXML
    private TableColumn<MeccsModel, Integer> priceColumn;

    @FXML
    private TableColumn<MeccsModel, String> typeColumn;

    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        startTimeColumn.setCellValueFactory(new PropertyValueFactory<>("startTime"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));

        // Mock types for the ComboBox
        typeComboBox.getItems().addAll("Típus 1", "Típus 2", "Típus 3");
    }

    @FXML
    private void applyFilter() {
        String date = dateField.getText();
        String type = typeComboBox.getValue();
        boolean includePremium = includePremiumCheckBox.isSelected();

        DatabaseController dbController = new DatabaseController();
        ResultSet resultSet = dbController.getFilteredMeccsData(date, type, includePremium);

        try {
            filteredDataTable.getItems().clear();
            while (resultSet.next()) {
                filteredDataTable.getItems().add(new MeccsModel(
                    resultSet.getInt("id"),
                    resultSet.getString("datum"),
                    resultSet.getString("kezdes"),
                    resultSet.getInt("belepo"),
                    resultSet.getString("tipus")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
