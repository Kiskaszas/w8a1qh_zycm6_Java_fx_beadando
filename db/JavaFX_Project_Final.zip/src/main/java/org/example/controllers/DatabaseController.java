
package org.example.controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseController {
    private static final String DB_URL = "jdbc:sqlite:c:/adatok/adatok.sqlite";

    public ResultSet getAllNezoData() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            String query = "SELECT id, nev, ferfi, berletes FROM nezo LIMIT 100;";
            return stmt.executeQuery(query);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet getFilteredMeccsData(String date, String type, boolean includePremium) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            String query = "SELECT id, datum, kezdes, belepo, tipus FROM meccs WHERE 1=1";

            if (date != null && !date.isEmpty()) {
                query += " AND datum = '" + date + "'";
            }
            if (type != null && !type.isEmpty()) {
                query += " AND tipus = '" + type + "'";
            }
            if (!includePremium) {
                query += " AND belepo < 5000"; // Assume premium tickets cost more than 5000
            }

            return stmt.executeQuery(query);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
