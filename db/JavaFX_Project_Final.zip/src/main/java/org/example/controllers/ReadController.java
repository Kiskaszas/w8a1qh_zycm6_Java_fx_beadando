
package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.models.NezoModel;

import java.sql.ResultSet;

public class ReadController {

    @FXML
    private TableView<NezoModel> dataTable;

    @FXML
    private TableColumn<NezoModel, Integer> idColumn;

    @FXML
    private TableColumn<NezoModel, String> nameColumn;

    @FXML
    private TableColumn<NezoModel, String> genderColumn;

    @FXML
    private TableColumn<NezoModel, String> subscriptionColumn;

    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
        subscriptionColumn.setCellValueFactory(new PropertyValueFactory<>("subscription"));

        DatabaseController dbController = new DatabaseController();
        ResultSet resultSet = dbController.getAllNezoData();

        try {
            while (resultSet.next()) {
                dataTable.getItems().add(new NezoModel(
                    resultSet.getInt("id"),
                    resultSet.getString("nev"),
                    resultSet.getString("ferfi").equals("true") ? "Férfi" : "Nő",
                    resultSet.getString("berletes").equals("true") ? "Bérletes" : "Nem bérletes"
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
