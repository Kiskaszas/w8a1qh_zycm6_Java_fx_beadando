
package org.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdateController {

    @FXML
    private ComboBox<Integer> idComboBox;

    @FXML
    private TextField nameField;

    @FXML
    private ComboBox<String> genderComboBox;

    @FXML
    private CheckBox subscriptionCheckBox;

    public void initialize() {
        // Populate the ID ComboBox with existing record IDs
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:c:/adatok/adatok.sqlite");
             PreparedStatement pstmt = conn.prepareStatement("SELECT id FROM nezo");
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                idComboBox.getItems().add(rs.getInt("id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        genderComboBox.getItems().addAll("Férfi", "Nő");
    }

    @FXML
    private void updateRecord() {
        Integer id = idComboBox.getValue();
        String name = nameField.getText();
        String gender = genderComboBox.getValue();
        boolean isSubscriber = subscriptionCheckBox.isSelected();

        if (id == null || name == null || name.isEmpty() || gender == null) {
            System.out.println("Hibás adatok! Minden mező kötelező.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:c:/adatok/adatok.sqlite");
             PreparedStatement pstmt = conn.prepareStatement(
                 "UPDATE nezo SET nev = ?, ferfi = ?, berletes = ? WHERE id = ?")) {
            pstmt.setString(1, name);
            pstmt.setString(2, gender.equals("Férfi") ? "true" : "false");
            pstmt.setString(3, isSubscriber ? "true" : "false");
            pstmt.setInt(4, id);
            pstmt.executeUpdate();
            System.out.println("Rekord sikeresen módosítva!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
