
package org.example.models;

public class MeccsModel {
    private int id;
    private String date;
    private String startTime;
    private int price;
    private String type;

    public MeccsModel(int id, String date, String startTime, int price, String type) {
        this.id = id;
        this.date = date;
        this.startTime = startTime;
        this.price = price;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
