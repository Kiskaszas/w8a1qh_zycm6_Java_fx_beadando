@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.mnb.hu/webservices/", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.example.soap;
